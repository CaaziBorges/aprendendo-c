#include <stdio.h>
#include <stdlib.h>
#include <math.h>

int main()
{
    int B;
    int A = 998; //Salario minimo
    float X, Y, Z, K; //Armazena os 4 ultimos salarios
    int C = A * 3; //Calcula quanto equivale 3 salarios minimos
    
    printf("Quantas pessoas vivem na sua casa ?");
    scanf("%d", &B);
    
    printf("Digite seus 4 ultimos salarios, 1º");
    scanf("%f", &X);

    printf("2º");
    scanf("%f", &Y);
    
    printf("3º");
    scanf("%f", &Z);

    printf("4º");
    scanf("%f", &K);
    
    float D = X+Y+Z+K; //Soma os 4 ultimos salarios
    
    float F = D/B;
    
    if(F > C){
        printf("Você recebe mais que tres salarios minimos!");
    } else{
        printf("Você recebe menos que 3 salarios minimos!");
    }
    
    
    return 0;
}

