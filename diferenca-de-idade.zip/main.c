#include <stdio.h>
#include <stdlib.h>

int main()
{
    int idade, idade2, operacao;
    
    
    printf("Digite a primeira idade");
    scanf("%d", &idade);
    
    printf("Digite a segunda idade");
    scanf("%d", &idade2);
    
    operacao = idade - idade2;
    
    printf("A diferença é: %d", operacao);
    
    system("pause");
    
    return 0;
}
