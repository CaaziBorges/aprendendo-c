#include <stdlib.h>
#include <math.h>
#include <stdio.h>

    
int main()
{
    int A; //Armazena a quantidade de condominos
    float B; //Armazena o valor da divida
    int D; //
    
    printf("Digite a quantidade de condominos.");
    scanf("%d", &A);
    
    printf("Digite o total da divida a ser dividida.");
    scanf("%f", &B);
    
    float C = A / B; //Armazena o resultado da divisão  
        
    printf("A divida de cada condomino é: %f", C);
        
    return 0;
}
