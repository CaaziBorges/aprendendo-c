#include <stdio.h>
#include <stdlib.h>
#include <math.h>

int main ()
{
    int A, B, C, D, E, F;

    printf("\n Digite a nota 1: \t");
    scanf("%d", &A);

    printf("\n Digite a nota 2: \t");
    scanf("%d", &B);

    printf("\n Digite a nota 3: \t");
    scanf("%d", &C);

    printf("\n Digite a nota 4: \t");
    scanf("%d", &D);

    E = A+B+C+D;
    F = E/4;
    
    printf("Sua média é:/n %d", F);

return 0;
}