#include <stdio.h>
#include <stdlib.h>
#include <math.h>

int main()
{
    int A, B, C[7], D[7], E[7], S[1];
    S[0] = 998; //Salario minimo
    
    //Recolhe a informação de quantas pessoas trabalham na sua casa
    printf("Quantas pessoas trabalham na sua casa ? \n");
    scanf("%d", &A);
    
    //Reconhe a informação de quantas pessoas vivem na sua casa
    printf("Quantas pessoas vivem na sua casa ? \n");
    scanf("%d", &B);
    
    //Recolhe os dados inseridos do valor de salarios das pessoas que trabalham na sua casa
    if(A==1){
        printf("Digite o ultimo salario da pessoa que trabalha na sua casa. \n");
        
        printf("Digite o salario da primeira pessoa. \t");
        scanf("%d", &C[0]);
    }
    
    if(A==2){
        printf("Digite os ultimos salario das pessoas que trabalha na sua casa. \n");
        
        printf("Digite o salario da primeira pessoa. \t");
        scanf("%d", &C[0]);
        
        printf("Digite o salario da segunda pessoa. \t");
        scanf("%d", &C[1]);
    }
    
    if(A==3){
        printf("Digite os ultimos salario das pessoas que trabalha na sua casa. \n");

        printf("Digite o salario da primeira pessoa. \t");
        scanf("%d", &C[0]);
        
        printf("Digite o salario da segunda pessoa. \t");
        scanf("%d", &C[1]);
        
        printf("Digite o salario da terceira pessoa. \t");
        scanf("%d", &C[2]);
    } 
    
    if(A==4){
        printf("Digite os ultimos salario das pessoas que trabalha na sua casa. \n");
        
        printf("Digite o salario da primeira pessoa. \t");
        scanf("%d", &C[0]);
        
        printf("Digite o salario da segunda pessoa. \t");
        scanf("%d", &C[1]);
        
        printf("Digite o salario da terceira pessoa. \t");
        scanf("%d", &C[2]);
        
        printf("Digite o salario da quarta pessoa. \t");
        scanf("%d", &C[3]);
    }   
    
    if(A==5){
        printf("Digite os ultimos salario das pessoas que trabalha na sua casa. \n");
        
        printf("Digite o salario da primeira pessoa. \t");
        scanf("%d", &C[0]);
        
        printf("Digite o salario da segunda pessoa. \t");
        scanf("%d", &C[1]);
        
        printf("Digite o salario da terceira pessoa. \t");
        scanf("%d", &C[2]);
        
        printf("Digite o salario da quarta pessoa. \t");
        scanf("%d", &C[3]);
        
        printf("Digite o salario da quinta pessoa. \t");
        scanf("%d", &C[4]);
    }    
        
    if(A==6){
        printf("Digite os ultimos salario das pessoas que trabalha na sua casa. \n");
        
        printf("Digite o salario da primeira pessoa. \t");
        scanf("%d", &C[0]);
        
        printf("Digite o salario da segunda pessoa. \t");
        scanf("%d", &C[1]);
        
        printf("Digite o salario da terceira pessoa. \t");
        scanf("%d", &C[2]);
        
        printf("Digite o salario da quarta pessoa. \t");
        scanf("%d", &C[3]);
        
        printf("Digite o salario da quinta pessoa. \t");
        scanf("%d", &C[4]);
        
        printf("Digite o salario da sexta pessoa. \t");
        scanf("%d", &C[5]);
    }
        
    if(A==7){
        printf("Digite os ultimos salario das pessoas que trabalha na sua casa. \n");
        
        printf("Digite o salario da primeira pessoa. \t");
        scanf("%d", &C[0]);
        
        printf("Digite o salario da segunda pessoa. \t");
        scanf("%d", &C[1]);
        
        printf("Digite o salario da terceira pessoa. \t");
        scanf("%d", &C[2]);
        
        printf("Digite o salario da quarta pessoa. \t");
        scanf("%d", &C[3]);
        
        printf("Digite o salario da quinta pessoa. \t");
        scanf("%d", &C[4]);
        
        printf("Digite o salario da sexta pessoa. \t");
        scanf("%d", &C[5]);
        
        printf("Digite o salario da setima pessoa. \t");
        scanf("%d", &C[6]);
    }
        
    if(A==8){
        printf("Digite os ultimos salario das pessoas que trabalha na sua casa.  \n");
        
        printf("Digite o salario da primeira pessoa. \t");
        scanf("%d", &C[0]);
        
        printf("Digite o salario da segunda pessoa. \t");
        scanf("%d", &C[1]);
        
        printf("Digite o salario da terceira pessoa. \t");
        scanf("%d", &C[2]);
        
        printf("Digite o salario da quarta pessoa. \t");
        scanf("%d", &C[3]);
        
        printf("Digite o salario da quinta pessoa. \t");
        scanf("%d", &C[4]);
        
        printf("Digite o salario da sexta pessoa. \t");
        scanf("%d", &C[5]);
        
        printf("Digite o salario da setima pessoa. \t");
        scanf("%d", &C[6]);

        printf("Digite o salario da oitava pessoa. \t");
        scanf("%d", &C[7]);
    }

    //soma dos salarios dos membros empregados
    D[0] = C[0];
    
    D[1] = C[0] + C[1];

    D[2] = C[0] + C[1] + C[2];
    
    D[3] = C[0] + C[1] + C[2] + C[3];
    
    D[4] = C[0] + C[1] + C[2] + C[3] + C[4];
    
    D[5] = C[0] + C[1] + C[2] + C[3] + C[4] + C[5];
    
    D[6] = C[0] + C[1] + C[2] + C[3]+ C[4] + C[5] + C[6];
    
    D[7] = C[0] + C[1] + C[2] + C[3] + C[4] + C[5] + C[6] + C[7];
    
    //divisão dos salarios pelo numero de moradores
    E[0] = D[0] / B;
    
    E[1] = D[1] / B;
    
    E[2] = D[2] / B;
    
    E[3] = D[3] / B;
    
    E[4] = D[4] / B;
    
    E[5] = D[5] / B;
    
    E[6] = D[6] / B;
    
    E[7] = D[7] / B;
   
    //armazena o salario minimo vezes tres
    S[1] = S[0] * 3;
    
    //printa o resultando dizendo se a renda é maior ou menor de 3 salarios minimos
    if(A == 1){
        
        if(E[0] > S[1])
            printf("Sua renda é superior a 3 salarios minimos!");
        else
            printf("Sua reda é inferior a 3 salarios minimos!");
    }
    
    if(A == 2){
        if(E[1] > S[1])
            printf("Sua renda é superior a 3 salarios minimos!");
        else
            printf("Sua reda é inferior a 3 salarios minimos!");
    }
    
    if(A == 3){
        
    
        if(E[2] > S[1])
            printf("Sua renda é superior a 3 salarios minimos!");
        else
            printf("Sua reda é inferior a 3 salarios minimos!");
    }
    
    if(A == 3){
        
    
        if(E[3] > S[1])
            printf("Sua renda é superior a 3 salarios minimos!");
        else
            printf("Sua reda é inferior a 3 salarios minimos!");
    }
    
    if(A == 4){
        
    
        if(E[4] > S[1])
            printf("Sua renda é superior a 3 salarios minimos!");
        else
            printf("Sua reda é inferior a 3 salarios minimos!");
    }
    
    if(A == 5){
        
        if(E[5] > S[1])
            printf("Sua renda é superior a 3 salarios minimos!");
        else
            printf("Sua reda é inferior a 3 salarios minimos!");
    }
    
    if(A == 6){
        
        if(E[6] > S[1])
            printf("Sua renda é superior a 3 salarios minimos!");
        else
            printf("Sua reda é inferior a 3 salarios minimos!");
    }
    
    if(A == 7){
        
        if(E[7] > S[1])
            printf("Sua renda é superior a 3 salarios minimos!");
        else
            printf("Sua reda é inferior a 3 salarios minimos!");
    }
    
    return 0;
}